"""사전실험 E1(순서) · E2(디블로킹) 공통 라이브러리"""
import json, os, subprocess, contextlib, io
import numpy as np, cv2

W, H = 1280, 720
CCTV_CLASSES = [1, 2, 3, 4, 6, 8]   # person, bicycle, car, motorcycle, bus, truck (COCO 순서 + 1)
BALL_CLASSES = [33]

# ---------------- 디코딩 / 인코딩 ----------------
def read_yuv(video, w, h, keep=None, vf=None):
    """yuv420p 그대로 디코딩. keep=None이면 전체 프레임 리스트, 아니면 {i: (y,u,v)}"""
    cmd = ["ffmpeg", "-v", "error", "-i", video]
    if vf: cmd += ["-vf", vf]
    cmd += ["-f", "rawvideo", "-pix_fmt", "yuv420p", "-"]
    fb = w * h * 3 // 2
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
    out = [] if keep is None else {}
    i = 0
    while True:
        b = p.stdout.read(fb)
        if len(b) < fb: break
        if keep is None or i in keep:
            a = np.frombuffer(b, np.uint8)
            f = (a[:w*h].reshape(h, w).copy(), a[w*h:w*h*5//4].reshape(h//2, w//2).copy(),
                 a[w*h*5//4:].reshape(h//2, w//2).copy())
            if keep is None: out.append(f)
            else: out[i] = f
        i += 1
    p.wait()
    if p.returncode: raise RuntimeError(f"decode failed: {video}")
    return out, i

def resize_yuv(f, w2, h2):
    """같은 함수(INTER_AREA)로 두 경로 모두 축소 -> 순서 외의 차이 제거"""
    y, u, v = f
    return (cv2.resize(y, (w2, h2), interpolation=cv2.INTER_AREA),
            cv2.resize(u, (w2//2, h2//2), interpolation=cv2.INTER_AREA),
            cv2.resize(v, (w2//2, h2//2), interpolation=cv2.INTER_AREA))

def yuv_to_bgr(f):
    y, u, v = f; h, w = y.shape
    buf = np.concatenate([y.ravel(), u.ravel(), v.ravel()]).reshape(h * 3 // 2, w)
    return cv2.cvtColor(buf, cv2.COLOR_YUV2BGR_I420)

def encode(frames, w, h, out, mode, val, x264_params=None, fps=30):
    """CCTV형 x264 (veryfast, zerolatency, B프레임 없음, GOP 60). mode: 'kbps'(1-pass CBR형) 또는 'qp'(고정 QP)"""
    cmd = ["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "yuv420p", "-s", f"{w}x{h}",
           "-r", str(fps), "-i", "-", "-c:v", "libx264", "-preset", "veryfast", "-tune", "zerolatency",
           "-profile:v", "high", "-pix_fmt", "yuv420p", "-g", "60", "-keyint_min", "60", "-sc_threshold", "0"]
    if mode == "kbps":
        cmd += ["-b:v", f"{val}k", "-maxrate", f"{val}k", "-bufsize", f"{val}k"]
    else:
        cmd += ["-qp", str(val)]
    if x264_params: cmd += ["-x264-params", x264_params]
    cmd += ["-an", out]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    for (y, u, v) in frames:
        p.stdin.write(y.tobytes()); p.stdin.write(u.tobytes()); p.stdin.write(v.tobytes())
    p.stdin.close(); p.wait()
    if p.returncode: raise RuntimeError(f"encode failed: {out}")

def kbps_of(p):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=bit_rate", "-of", "csv=p=0", p],
                       capture_output=True, text=True).stdout.strip()
    return round(int(r) / 1000, 1) if r.isdigit() else None

def has_filter(name):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-filters"], capture_output=True, text=True).stdout
    return any(l.split()[1:2] == [name] for l in r.splitlines() if len(l.split()) > 1)

def psnr(a, b):
    mse = float(((a.astype(np.float64) - b.astype(np.float64)) ** 2).mean())
    return 99.0 if mse == 0 else 10 * np.log10(255.0 ** 2 / mse)

# ---------------- GT ----------------
def build_gt(raw, n, names):
    images, anns, aid = [], [], 0
    for i in range(n):
        images.append({"id": i, "width": W, "height": H})
        for o in raw.get(str(2 * i + 1), []):
            x1, y1, x2, y2 = o["x_min"] * W, o["y_min"] * H, o["x_max"] * W, o["y_max"] * H
            w, h = x2 - x1, y2 - y1
            if w <= 0 or h <= 0: continue
            aid += 1
            anns.append({"id": aid, "image_id": i, "category_id": int(o["class_id"]), "bbox": [x1, y1, w, h],
                         "area": w * h, "iscrowd": int(o.get("iscrowd", 0)), "track_id": o.get("track_id")})
    return {"images": images, "annotations": anns, "categories": [{"id": i + 1, "name": n_} for i, n_ in enumerate(names)]}

def size_class(a):
    return "small" if a < 32 ** 2 else ("medium" if a < 96 ** 2 else "large")

# ---------------- 매칭 (B-3·C와 같은 규칙) ----------------
def match_detected(gt_boxes, gt_cls, pred, conf_thr=0.25, iou_thr=0.5):
    det = np.zeros(len(gt_boxes), bool)
    if len(gt_boxes) == 0 or len(pred) == 0: return det
    p = pred[pred[:, 4] >= conf_thr]
    if len(p) == 0: return det
    p = p[np.argsort(-p[:, 4])]
    g = gt_boxes
    gx2, gy2, px2, py2 = g[:, 0] + g[:, 2], g[:, 1] + g[:, 3], p[:, 0] + p[:, 2], p[:, 1] + p[:, 3]
    iw = np.clip(np.minimum(gx2[:, None], px2[None]) - np.maximum(g[:, 0][:, None], p[:, 0][None]), 0, None)
    ih = np.clip(np.minimum(gy2[:, None], py2[None]) - np.maximum(g[:, 1][:, None], p[:, 1][None]), 0, None)
    inter = iw * ih
    iou = inter / np.maximum((g[:, 2] * g[:, 3])[:, None] + (p[:, 2] * p[:, 3])[None] - inter, 1e-9)
    iou = np.where(gt_cls[:, None] == p[None, :, 5], iou, 0.0)
    for j in range(len(p)):
        col = np.where(det, -1.0, iou[:, j]); k = int(np.argmax(col))
        if col[k] >= iou_thr: det[k] = True
    return det

def coco_ap(gt, preds, classes):
    from pycocotools.coco import COCO
    from pycocotools.cocoeval import COCOeval
    if not preds: return None
    with contextlib.redirect_stdout(io.StringIO()):
        cg = COCO(); cg.dataset = gt; cg.createIndex(); cd = cg.loadRes(preds)
        E = COCOeval(cg, cd, "bbox"); E.params.catIds = classes
        E.evaluate(); E.accumulate(); E.summarize()
    f = lambda x: None if x < 0 else round(100 * x, 2)
    s = E.stats
    return {"AP": f(s[0]), "AP50": f(s[1]), "APs": f(s[3]), "APm": f(s[4]), "APl": f(s[5]), "ARs": f(s[9])}

def cluster_boot(cid, fn, B=1000, seed=0):
    rng = np.random.default_rng(seed); K = int(cid.max()) + 1
    point = fn(np.ones(len(cid))); vals = []
    for _ in range(B):
        cnt = np.bincount(rng.integers(0, K, K), minlength=K)
        v = fn(cnt[cid].astype(float))
        if v is not None and np.isfinite(v): vals.append(v)
    if not vals: return point, np.nan, np.nan
    return point, float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))

# ---------------- E3: PyAV로 디코딩하면서 매크로블록 QP 지도와 프레임 유형 추출 ----------------
def decode_with_qp(video, keep, w=1280, h=720):
    """반환: {i: (y,u,v)}, {i: qp_map (h/16, w/16)}, {i: 'I'|'P'|'B'}"""
    import av
    c = av.open(video); s = c.streams.video[0]
    s.codec_context.options = {"export_side_data": "venc_params"}
    T = av.sidedata.sidedata.Type
    frames, qps, ptypes = {}, {}, {}
    for i, fr in enumerate(c.decode(s)):
        if i not in keep: continue
        sd = fr.side_data.get(T.VIDEO_ENC_PARAMS)
        if sd is None: raise RuntimeError("QP side data 없음: PyAV/FFmpeg 버전 확인")
        qps[i] = np.asarray(sd.qp_map(), dtype=np.float32)
        ptypes[i] = {1: "I", 2: "P", 3: "B"}.get(int(fr.pict_type), str(fr.pict_type))
        a = fr.to_ndarray(format="yuv420p")            # (h*3/2, w)
        frames[i] = (a[:h].copy(), a[h:h + h // 4].reshape(h // 2, w // 2).copy(),
                     a[h + h // 4:].reshape(h // 2, w // 2).copy())
    c.close()
    return frames, qps, ptypes

def box_mb(b, mbw=80, mbh=45, mb=16):
    x, y, w, h = b
    x0, y0 = int(max(0, x // mb)), int(max(0, y // mb))
    x1, y1 = int(min(mbw, -(-(x + w) // mb))), int(min(mbh, -(-(y + h) // mb)))
    return x0, max(x0 + 1, x1), y0, max(y0 + 1, y1)

def qp_features(q, b):
    """객체 매크로블록 평균·최대 QP, 같은 행 배경(객체 열 제외) 평균 QP, 프레임 평균 QP"""
    x0, x1, y0, y1 = box_mb(b, q.shape[1], q.shape[0])
    obj = q[y0:y1, x0:x1]
    rows = q[y0:y1].copy(); rows[:, x0:x1] = np.nan
    bg = np.nanmean(rows) if np.isfinite(rows).any() else np.nan
    return float(obj.mean()), float(obj.max()), float(bg), float(q.mean())

# ---------------- E4: 레이트 컨트롤 설정별 인코딩, 전체 프레임 디코딩 ----------------
def has_encoder(name):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-encoders"], capture_output=True, text=True).stdout
    return any(len(l.split()) > 1 and l.split()[1] == name for l in r.splitlines())

def encode_args(frames, w, h, out, vargs, fps=30):
    """vargs: 코덱·레이트 컨트롤 인자 리스트 (예: ['-c:v','libx264',...])"""
    cmd = ["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "yuv420p", "-s", f"{w}x{h}", "-r", str(fps),
           "-i", "-"] + vargs + ["-an", out]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    for (y, u, v) in frames:
        p.stdin.write(y.tobytes()); p.stdin.write(u.tobytes()); p.stdin.write(v.tobytes())
    p.stdin.close(); p.wait()
    if p.returncode: raise RuntimeError(f"encode failed: {out}")

def decode_all_with_qp(video, w=1280, h=720):
    """전체 프레임: (yuv 리스트, 프레임 평균 QP 배열(없으면 NaN), 프레임 유형 리스트, 패킷 바이트 배열)"""
    import av
    c = av.open(video); s = c.streams.video[0]
    s.codec_context.options = {"export_side_data": "venc_params"}
    T = av.sidedata.sidedata.Type
    yuv, qp, pt, nb = [], [], [], []
    for pkt in c.demux(s):
        size = pkt.size
        for fr in pkt.decode():
            sd = fr.side_data.get(T.VIDEO_ENC_PARAMS)
            qp.append(float(np.asarray(sd.qp_map()).mean()) if sd is not None else np.nan)
            pt.append({1: "I", 2: "P", 3: "B"}.get(int(fr.pict_type), str(fr.pict_type)))
            nb.append(size)
            a = fr.to_ndarray(format="yuv420p")
            yuv.append((a[:h].copy(), a[h:h + h // 4].reshape(h // 2, w // 2).copy(), a[h + h // 4:].reshape(h // 2, w // 2).copy()))
    c.close()
    return yuv, np.array(qp), pt, np.array(nb)

# ---------------- E6: 색차 처리 ----------------
GRAY_U = np.full((360, 640), 128, np.uint8)

def gray_bgr_from_y(y):
    return yuv_to_bgr((y, GRAY_U, GRAY_U))

def bgr_to_uv(bgr):
    """BGR -> I420의 U, V (yuv_to_bgr과 같은 BT.601 limited range의 역변환)"""
    import cv2
    yuv = cv2.cvtColor(bgr, cv2.COLOR_BGR2YUV_I420)
    h, w = bgr.shape[:2]
    u = yuv[h:h + h // 4].reshape(h // 2, w // 2); v = yuv[h + h // 4:].reshape(h // 2, w // 2)
    return u.copy(), v.copy()

def chroma_pearson(u1, v1, u2, v2):
    a = np.concatenate([u1.ravel(), v1.ravel()]).astype(np.float64)
    b = np.concatenate([u2.ravel(), v2.ravel()]).astype(np.float64)
    if a.std() == 0 or b.std() == 0: return 0.0
    return float(np.corrcoef(a, b)[0, 1])

# ---------------- E7: 색차 업샘플링 (모든 조건에 같은 BT.601 limited 변환) ----------------
def yuv444_to_bgr(y, U, V):
    """y: (H,W) uint8, U,V: (H,W) float/uint8 전해상도 색차 -> BGR uint8. OpenCV I420과 같은 계수"""
    Y = 1.164 * (y.astype(np.float32) - 16.0); u = U.astype(np.float32) - 128.0; v = V.astype(np.float32) - 128.0
    r = Y + 1.596 * v; g = Y - 0.813 * v - 0.391 * u; b = Y + 2.018 * u
    return np.clip(np.dstack([b, g, r]) + 0.5, 0, 255).astype(np.uint8)

def up_nearest(c):
    return np.repeat(np.repeat(c, 2, axis=0), 2, axis=1).astype(np.float32)

def up_bilinear(c):
    import cv2
    h, w = c.shape
    return cv2.resize(c.astype(np.float32), (w * 2, h * 2), interpolation=cv2.INTER_LINEAR)

def _box(x, r):
    import cv2
    return cv2.boxFilter(x, -1, (2 * r + 1, 2 * r + 1), borderType=cv2.BORDER_REFLECT)

def guided_filter(I, p, r, eps):
    """He et al. 가이드 필터. I: 길잡이(휘도), p: 입력(업샘플된 색차), 값 범위 0~1"""
    mI, mp = _box(I, r), _box(p, r)
    vI = _box(I * I, r) - mI * mI; cIp = _box(I * p, r) - mI * mp
    a = cIp / (vI + eps); b = mp - a * mI
    return _box(a, r) * I + _box(b, r)

def up_guided(y, c, r=4, eps=1e-3):
    I = y.astype(np.float32) / 255.0; p = up_bilinear(c) / 255.0
    return np.clip(guided_filter(I, p, r, eps), 0, 1) * 255.0

def up_lm(y, c, r=2, eps=1e-3):
    """저해상도에서 색차 = a·휘도 + b 국소 선형 모델을 맞추고, 원해상도 휘도에 적용 (빠른 가이드 업샘플링, CCLM과 같은 원리)"""
    import cv2
    h, w = c.shape
    Il = cv2.resize(y, (w, h), interpolation=cv2.INTER_AREA).astype(np.float32) / 255.0; pl = c.astype(np.float32) / 255.0
    mI, mp = _box(Il, r), _box(pl, r)
    vI = _box(Il * Il, r) - mI * mI; cIp = _box(Il * pl, r) - mI * mp
    a = cIp / (vI + eps); b = mp - a * mI
    a, b = _box(a, r), _box(b, r)
    A = cv2.resize(a, (w * 2, h * 2), interpolation=cv2.INTER_LINEAR); B = cv2.resize(b, (w * 2, h * 2), interpolation=cv2.INTER_LINEAR)
    return np.clip(A * (y.astype(np.float32) / 255.0) + B, 0, 1) * 255.0

# ---------------- 실험 C: 8x8 블록 DCT 대역 개입 ----------------
from scipy.fft import dctn, idctn
def bdct(y):
    return dctn(y.reshape(H // 8, 8, W // 8, 8).transpose(0, 2, 1, 3), axes=(2, 3), norm="ortho")
def ibdct(c):
    return idctn(c, axes=(2, 3), norm="ortho").transpose(0, 2, 1, 3).reshape(H, W)
_UV = np.add.outer(np.arange(8), np.arange(8))
BAND = {"Low": (_UV >= 1) & (_UV <= 2), "Mid": (_UV >= 3) & (_UV <= 6), "High": _UV >= 7}
def band_replace(Dc, Dr, band):
    out = Dc.copy(); m = BAND[band]; out[..., m] = Dr[..., m]; return ibdct(out)
def band_remove(Dc, band):
    out = Dc.copy(); out[..., BAND[band]] = 0.0; return ibdct(out)
def letterbox_params(imgsz, stride=32):
    r = min(imgsz / H, imgsz / W); nw, nh = round(W * r), round(H * r)
    return r, (-(-nw // stride) * stride - nw) / 2, (-(-nh // stride) * stride - nh) / 2, -(-nh // stride) * stride

def to_u8(y):
    return np.clip(np.rint(y), 0, 255).astype(np.uint8)
